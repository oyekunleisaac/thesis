let questions = [
    {
    numb: 1,
    question: "Which is not an input device?",
    answer: "Monitor",
    options: [
      "Light pen",
      "Mouse",
      "Monitor",
      "Keyboard"
    ]
  },
    {
    numb: 2,
    question: "Which of these teams have won the World Cup twice?",
    answer: "Uruguay",
    options: [
      "Argentina",
      "England",
      "Uruguay",
      "Brazil"
    ]
  },
    {
    numb: 3,
    question: "Which of these German teams have won the champions league?",
    answer: "Hamburg",
    options: [
      "Hamburg",
      "Frankfurt",
      "RB Leipzig",
      "FC Cologne"
    ]
  },
    {
    numb: 4,
    question: "In what season did Roman Abramovich take over Chelsea?",
    answer: "2003/04",
    options: [
      "2005/06",
      "2003/04",
      "2004/05",
      "2002/03"
    ]
  },
    {
    numb: 5,
    question: "'Estadio da Luz' stadium belongs to what club?",
    answer: "Benfica Lisbon",
    options: [
      "Benfica Lisbon",
      "Galatasaray",
      "FC Porto",
      "Valencia"
    ]
  },
  // you can uncomment the below codes and make duplicate as more as you want to add question
  // but remember you need to give the numb value serialize like 1,2,3,5,6,7,8,9.....

  //   {
  //   numb: 6,
  //   question: "Your Question is Here",
  //   answer: "Correct answer of the question is here",
  //   options: [
  //     "Option 1",
  //     "option 2",
  //     "option 3",
  //     "option 4"
  //   ]
  // },
];