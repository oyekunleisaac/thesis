<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
// use App\Http\Requests;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Storage;
use App\Models\User;
use App\Models\Premium;
use App\Models\Verify;
use App\Models\Verification;
use File;
use Response;
use Auth;
use DB;

class AdminController extends Controller
{
    public function data()
    {
       
    //    $verify = verify::all()->where('role',1)->get();
    //     return $verify;
       if (Auth::user()->role == 0)
        
        return redirect('home'); 
        
        if (Auth::user()->role == 2)
        
        return redirect('admin/admin'); 

        $verify = DB::table('verifies')->select('*')->where('user_id', Auth::user()->id)->pluck('role');
            //return $verify;
            if ($verify == '[0]')
            return redirect('admin/verify'); 
        
       $view = Premium::all()->where('user_id', Auth::user()->id) ;
       $users = User::all();
        
        return view('admin/dashboard' , compact('view','users'));
    }

  
    public function book(Request $request)
     {
        if (Auth::user()->role == 0)
        {
        return redirect('home'); 
        } 
                
            if ($request->hasFile('image')) 
                {
                    $image = $request->file('image');
                    $books = $request->file('book');
                    $image_name = time().'.'.$image->getClientOriginalExtension();
                    $book_name = time().'.'.$books->getClientOriginalExtension();
                    $destinationPath = public_path('files');
                    $image->move($destinationPath, $image_name);
                    $books->move($destinationPath, $book_name);

            $book = new Premium([
            'title'      =>  $request->get('title'),
            'author'       =>  $request->get('author'),
            'user_id'       =>  $request->get('user_id'),
            'description'       =>  $request->get('description'),
            'avb'       =>  $request->get('avb'),
            'value'          =>  $request->get('value'),
            'image'            =>  $image_name,
            'book'        =>  $books,
            ]);

            $book->save();
            return redirect()->back();
        }
            }

    public function viewpdf()
        {
            $book = Premium::get('book');
                    //return $book;
            return Response::make(file_get_contents('files/1670796636.pdf'), 200, [
                'content-type'=>'application/pdf',
            ]);
        }

    public function verifying()
        {
            if (Auth::user()->role == 0)
            return redirect('home'); 
            elseif (Auth::user()->role == 2)
            return redirect('admin/admin');        
            $verify = DB::table('verifies')->select('*')->where('user_id', Auth::user()->id)->pluck('role');
            //return $verify;
            if ($verify == '[1]')
            return redirect('admin/dashboard'); 
            elseif (Auth::user()->role == 1 && $verify == '[0]')
            return redirect('admin/done'); 

            

           $view = Premium::all();
           $user = User::all();
           return view('admin/verify', compact('view','user'));
        
        }

    public function verify(Request $request)
        {
           
            if (Auth::user()->role == 0)
                 return redirect('home'); 
            elseif (Auth::user()->role == 2)
                 return redirect('admin/admin'); 
                       
        $user = User::all();

        $author = new Verify;
            
        $author -> sub = $request->input('sub');
        $author -> dur = $request->input('dur');
        $author -> free = $request->input('free');
        $author -> copy = $request->input('copy');
        $author -> share = $request->input('share');
        $author -> user_id = Auth::user()->id;
        $author -> user_role = Auth::user()->role;
        $author -> role = Auth::user()->role;

        $author->save();
        return view('admin/done', compact('user'));
        
        }

    public function done()
        {
            if (Auth::user()->role == 0)
            return redirect('home'); 
            elseif (Auth::user()->role == 2)
            return redirect('admin/admin');


           $user = User::all();
            return view('admin/done', compact('user'));
        
        }

        public function admin()
        {
            //return $verification;
            if (Auth::user()->role == 0)
            
            return redirect('home'); 
            
            elseif (Auth::user()->role == 1)

            return redirect('admin/dashboard'); 
           
            $users = User::all()->where('role',1);
            $verify = Verify::all()->where('user_role',1);

            return view('admin/admin', compact('users','verify'));

        
        }
        public function verification(Request $request)
        {
           
            if (Auth::user()->role == 0)
            
            return redirect('home'); 
            
            elseif (Auth::user()->role == 1)

            return redirect('admin/dashboard'); 
                       
            $users = User::all()->where('role',1);
            $verify = Verify::all()->where('user_role',1);
                      
            $ver = Verify::find($request->id);
                
            $ver -> user_id = $request->user_id;
            $ver -> sub = $request->sub;
            $ver -> dur = $request->dur;
            $ver -> free = $request->free;
            $ver -> copy = $request->copy;
            $ver -> share = $request->share;
            $ver -> role = $request->role;
           
            $ver->save();
            
            return redirect()->back();
        
        }
}